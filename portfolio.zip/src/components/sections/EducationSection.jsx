import React from 'react';
import { portfolioData } from '../../data/portfolioData';
import SectionWrapper from '../layout/SectionWrapper';
import { GraduationCap, MapPin, Calendar } from 'lucide-react';

const EducationSection = () => {
  return (
    <SectionWrapper id="education" title="Education" className="bg-white">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {portfolioData.education.map((edu, index) => (
          <div 
            key={index} 
            className="bg-gray-50 rounded-2xl p-6 md:p-8 border border-gray-100 hover:border-primary-200 transition-colors group relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-24 h-24 bg-primary-100 rounded-full -mr-12 -mt-12 opacity-50 group-hover:scale-150 transition-transform duration-500"></div>
            
            <div className="relative z-10">
              <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-primary-600 mb-6 shadow-sm border border-gray-100">
                <GraduationCap size={24} />
              </div>
              
              <h3 className="text-xl font-bold text-gray-900 mb-2 leading-tight">
                {edu.degree}
              </h3>
              <p className="text-lg font-medium text-gray-700 mb-4">
                {edu.institution}
              </p>
              
              <div className="flex flex-col space-y-2 text-sm text-gray-500">
                <div className="flex items-center">
                  <Calendar size={16} className="mr-2 text-gray-400" />
                  {edu.duration}
                </div>
                <div className="flex items-center">
                  <MapPin size={16} className="mr-2 text-gray-400" />
                  {edu.location}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </SectionWrapper>
  );
};

export default EducationSection;
