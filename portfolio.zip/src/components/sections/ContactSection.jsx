import React from 'react';
import { portfolioData } from '../../data/portfolioData';
import SectionWrapper from '../layout/SectionWrapper';
import { Mail, Phone, MapPin } from 'lucide-react';
import { FaGithub, FaLinkedin } from 'react-icons/fa';

const ContactSection = () => {
  const { email, phone, location, linkedin, github } = portfolioData.personal;

  return (
    <SectionWrapper id="contact" title="Get In Touch" subtitle="Currently open for new opportunities. Feel free to reach out!" className="bg-white">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-12 max-w-5xl mx-auto">
        
        {/* Contact Info */}
        <div className="md:col-span-5 space-y-8">
          <div className="bg-gray-50 rounded-2xl p-6 border border-gray-100 flex items-center group hover:bg-primary-50 transition-colors">
            <div className="w-12 h-12 bg-white rounded-full shadow-sm flex items-center justify-center text-primary-600 mr-5 group-hover:scale-110 transition-transform">
              <Mail size={20} />
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium mb-1">Email</p>
              <a href={`mailto:${email}`} className="text-gray-900 font-semibold hover:text-primary-600 transition-colors">
                {email}
              </a>
            </div>
          </div>
          
          <div className="bg-gray-50 rounded-2xl p-6 border border-gray-100 flex items-center group hover:bg-primary-50 transition-colors">
            <div className="w-12 h-12 bg-white rounded-full shadow-sm flex items-center justify-center text-primary-600 mr-5 group-hover:scale-110 transition-transform">
              <Phone size={20} />
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium mb-1">Phone</p>
              <a href={`tel:${phone.replace(/[^0-9+]/g, '')}`} className="text-gray-900 font-semibold hover:text-primary-600 transition-colors">
                {phone}
              </a>
            </div>
          </div>
          
          <div className="bg-gray-50 rounded-2xl p-6 border border-gray-100 flex items-center group hover:bg-primary-50 transition-colors">
            <div className="w-12 h-12 bg-white rounded-full shadow-sm flex items-center justify-center text-primary-600 mr-5 group-hover:scale-110 transition-transform">
              <MapPin size={20} />
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium mb-1">Location</p>
              <span className="text-gray-900 font-semibold">
                {location}
              </span>
            </div>
          </div>
        </div>
        
        {/* Contact Form / Social Links */}
        <div className="md:col-span-7 bg-white rounded-3xl p-8 md:p-10 border border-gray-100 shadow-sm flex flex-col justify-center text-center">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">Let's Connect</h3>
          <p className="text-gray-600 mb-8 max-w-sm mx-auto">
            I'm always interested in hearing about new projects, opportunities, or just to chat about technology.
          </p>
          
          <div className="flex justify-center space-x-4">
            <a 
              href={`https://${linkedin}`} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="px-6 py-3 bg-[#0A66C2] text-white rounded-lg font-medium flex items-center hover:bg-[#004182] transition-colors shadow-sm hover:shadow-md hover:-translate-y-0.5"
            >
              <FaLinkedin size={20} className="mr-2" />
              LinkedIn
            </a>
            <a 
              href={`https://${github}`} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="px-6 py-3 bg-[#24292e] text-white rounded-lg font-medium flex items-center hover:bg-black transition-colors shadow-sm hover:shadow-md hover:-translate-y-0.5"
            >
              <FaGithub size={20} className="mr-2" />
              GitHub
            </a>
          </div>
        </div>

      </div>
    </SectionWrapper>
  );
};

export default ContactSection;
