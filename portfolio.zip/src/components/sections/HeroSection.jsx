// import React from "react";
// import { ArrowRight, Download } from "lucide-react";
// import { FaGithub, FaLinkedin } from "react-icons/fa";
// import { portfolioData } from "../../data/portfolioData";

// const HeroSection = () => {
//   const { name, role, summary, github, linkedin } = portfolioData.personal;

//   return (
//     <section
//       id="hero"
//       className="min-h-[90vh] flex items-center relative overflow-hidden"
//     >
//       {/* Background decoration */}
//       <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-primary-100/50 blur-3xl -z-10"></div>
//       <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-72 h-72 rounded-full bg-blue-100/50 blur-3xl -z-10"></div>

//       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 w-full flex flex-col md:flex-row items-center justify-between">
//         <div className="md:w-3/5 space-y-8">
//           <div>
//             <p className="text-primary-600 font-medium tracking-wide uppercase mb-3">
//               Hello, I am
//             </p>
//             <h1 className="text-5xl md:text-7xl font-extrabold text-gray-900 tracking-tight mb-4">
//               {name}
//             </h1>
//             <h2 className="text-2xl md:text-4xl font-bold text-gray-600 mb-6">
//               {role}
//             </h2>
//             <p className="text-lg text-gray-500 max-w-xl leading-relaxed">
//               {summary.split(".")[0]}. {summary.split(".")[1]}.
//             </p>
//           </div>

//           <div className="flex flex-wrap gap-4 pt-4">
//             <a
//               href="#projects"
//               className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-lg text-white bg-primary-600 hover:bg-primary-700 transition-all shadow-sm hover:shadow-md hover:-translate-y-0.5"
//             >
//               View Projects
//               <ArrowRight className="ml-2 -mr-1" size={20} />
//             </a>
//             <a
//               href="#contact"
//               className="inline-flex items-center justify-center px-6 py-3 border border-gray-300 text-base font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 transition-all shadow-sm hover:shadow-md hover:-translate-y-0.5"
//             >
//               Contact Me
//             </a>
//             {/* Optional Download Resume Button */}
//             {/* <a href="/resume.pdf" target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center px-6 py-3 text-base font-medium text-primary-600 hover:text-primary-700 transition-colors">
//               <Download className="mr-2" size={20} />
//               Resume
//             </a> */}
//             <a
//               href="/resume.pdf"
//               download="Deepak-Kumar-Resume.pdf"
//               className="inline-flex items-center justify-center px-6 py-3 text-base font-medium text-primary-600 hover:text-primary-700 transition-colors"
//             >
//               <Download className="mr-2" size={20} />
//               {/* Resume */}
//             </a>
//           </div>

//           <div className="flex items-center space-x-6 pt-6 border-t border-gray-200">
//             <a
//               href={`https://${github}`}
//               target="_blank"
//               rel="noopener noreferrer"
//               className="text-gray-400 hover:text-gray-900 transition-colors flex items-center gap-2"
//             >
//               <FaGithub size={24} />
//               <span className="font-medium">GitHub</span>
//             </a>
//             <a
//               href={`https://${linkedin}`}
//               target="_blank"
//               rel="noopener noreferrer"
//               className="text-gray-400 hover:text-blue-600 transition-colors flex items-center gap-2"
//             >
//               <FaLinkedin size={24} />
//               <span className="font-medium">LinkedIn</span>
//             </a>
//           </div>
//         </div>
//       </div>
//     </section>
//   );
// };

// export default HeroSection;



import React from 'react';
import { ArrowRight, Download } from 'lucide-react';
import { FaGithub, FaLinkedin } from 'react-icons/fa';
import { portfolioData } from '../../data/portfolioData';

const HeroSection = () => {
  const { name, role, summary, github, linkedin } = portfolioData.personal;

  return (
    <section
      id="hero"
      className="min-h-[90vh] flex items-center relative overflow-hidden"
    >
      {/* Background decoration */}
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-primary-100/50 blur-3xl -z-10"></div>

      <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-72 h-72 rounded-full bg-blue-100/50 blur-3xl -z-10"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 w-full flex flex-col md:flex-row items-center justify-between">

        {/* ================= LEFT SIDE ================= */}
        <div className="md:w-3/5 space-y-8">

          <div>
            <p className="text-primary-600 font-medium tracking-wide uppercase mb-3">
              Hello, I am
            </p>

            <h1 className="text-5xl md:text-7xl font-extrabold text-gray-900 tracking-tight mb-4">
              {name}
            </h1>

            <h2 className="text-2xl md:text-4xl font-bold text-gray-600 mb-6">
              {role}
            </h2>

            <p className="text-lg text-gray-500 max-w-xl leading-relaxed">
              {summary.split('.')[0]}. {summary.split('.')[1]}.
            </p>
          </div>

          {/* Buttons */}
          <div className="flex flex-wrap gap-4 pt-4">

            {/* View Projects */}
            <a
              href="#projects"
              className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-lg text-white bg-primary-600 hover:bg-primary-700 transition-all shadow-sm hover:shadow-md hover:-translate-y-0.5"
            >
              View Projects

              <ArrowRight
                className="ml-2 -mr-1"
                size={20}
              />
            </a>

            {/* Contact Me */}
            <a
              href="#contact"
              className="inline-flex items-center justify-center px-6 py-3 border border-gray-300 text-base font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 transition-all shadow-sm hover:shadow-md hover:-translate-y-0.5"
            >
              Contact Me
            </a>

            {/* Download Resume */}
            <a
              href="/resume.pdf"
              download="Deepak-Kumar-Resume.pdf"
              className="inline-flex items-center justify-center px-6 py-3 text-base font-medium text-primary-600 hover:text-primary-700 transition-colors"
            >
              <Download
                className="mr-2"
                size={20}
              />

              Resume
            </a>
          </div>

          {/* Social Links */}
          <div className="flex items-center space-x-6 pt-6 border-t border-gray-200">

            {/* GitHub */}
            <a
              href={`https://${github}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-400 hover:text-gray-900 transition-colors flex items-center gap-2"
            >
              <FaGithub size={24} />

              <span className="font-medium">
                GitHub
              </span>
            </a>

            {/* LinkedIn */}
            <a
              href={`https://${linkedin}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-400 hover:text-blue-600 transition-colors flex items-center gap-2"
            >
              <FaLinkedin size={24} />

              <span className="font-medium">
                LinkedIn
              </span>
            </a>

          </div>
        </div>


        {/* ================= RIGHT SIDE - PROFILE IMAGE ================= */}
        {/* <div className="md:w-2/5 flex justify-center items-center mt-12 md:mt-0">

          <div className="relative">

      
            <div className="absolute inset-0 rounded-full bg-primary-100 blur-2xl scale-110 -z-10"></div>

      
            <img
              src="/deepak image.jpeg"
              alt={name}
              className="w-72 h-72 md:w-96 md:h-96 object-cover rounded-full shadow-2xl border-8 border-white"
            />

          </div>

        </div> */}

        {/* ================= RIGHT SIDE - DEVELOPER VISUAL ================= */}
{/* ================= RIGHT SIDE - DEVELOPER VISUAL ================= */}
<div className="md:w-2/5 flex justify-center items-center mt-12 md:mt-0">

  <div className="relative w-full max-w-[520px]">

    {/* Decorative background */}
    <div className="absolute inset-0 bg-primary-100/50 blur-3xl rounded-full scale-110"></div>

    {/* Developer Illustration */}
    <img
      src="/full stack1.jpg"
      alt="Full Stack Developer"
      className="relative w-full h-[420px] md:h-[500px] object-contain"
    />

  </div>

</div>

      </div>
    </section>
  );
};

export default HeroSection;