import React from 'react';
import { portfolioData } from '../../data/portfolioData';
import SectionWrapper from '../layout/SectionWrapper';
import { Award, Trophy } from 'lucide-react';

const CertificationsSection = () => {
  return (
    <SectionWrapper id="certifications" title="Certifications & Achievements" className="bg-gray-50">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Certifications */}
        <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm">
          <div className="flex items-center mb-6">
            <div className="w-10 h-10 bg-primary-50 rounded-lg flex items-center justify-center text-primary-600 mr-4">
              <Award size={20} />
            </div>
            <h3 className="text-xl font-bold text-gray-900">Certifications</h3>
          </div>
          
          <ul className="space-y-4">
            {portfolioData.certifications.map((cert, index) => (
              <li key={index} className="flex items-start">
                <div className="w-2 h-2 rounded-full bg-primary-400 mt-2 mr-3 flex-shrink-0"></div>
                <span className="text-gray-700">{cert}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Achievements */}
        <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-5">
            <Trophy size={120} />
          </div>
          
          <div className="relative z-10">
            <div className="flex items-center mb-6">
              <div className="w-10 h-10 bg-yellow-50 rounded-lg flex items-center justify-center text-yellow-600 mr-4">
                <Trophy size={20} />
              </div>
              <h3 className="text-xl font-bold text-gray-900">Achievements</h3>
            </div>
            
            <ul className="space-y-4">
              {portfolioData.achievements.map((achievement, index) => (
                <li key={index} className="flex items-start">
                  <div className="w-2 h-2 rounded-full bg-yellow-400 mt-2 mr-3 flex-shrink-0"></div>
                  <span className="text-gray-700 font-medium">{achievement}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
      </div>
    </SectionWrapper>
  );
};

export default CertificationsSection;
