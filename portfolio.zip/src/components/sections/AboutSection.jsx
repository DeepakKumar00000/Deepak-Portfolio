// import React from 'react';
// import { portfolioData } from '../../data/portfolioData';
// import SectionWrapper from '../layout/SectionWrapper';

// const AboutSection = () => {
//   return (
//     <SectionWrapper id="about" title="About Me" className="bg-white">
//       <div className="max-w-3xl">
//         <p className="text-lg text-gray-600 leading-relaxed mb-6">
//           {portfolioData.personal.summary}
//         </p>
//         <p className="text-lg text-gray-600 leading-relaxed">
//           I specialize in {portfolioData.skills.frontend.slice(0, 3).join(', ')} on the frontend, and {portfolioData.skills.backend.slice(0, 3).join(', ')} on the backend. My passion lies in building high-performance, user-centric enterprise and SaaS applications that solve real-world problems.
//         </p>
//       </div>
//     </SectionWrapper>
//   );
// };

// export default AboutSection;


import React from 'react';
import { portfolioData } from '../../data/portfolioData';
import SectionWrapper from '../layout/SectionWrapper';
// import { Github, Linkedin, Code2, Cloud, Database } from 'lucide-react';
import { FaGithub, FaLinkedin } from 'react-icons/fa';

const AboutSection = () => {
  return (
    <SectionWrapper
      id="about"
      title="About Me"
      className="bg-white"
    >
      <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-stretch">

        {/* Left - Profile */}
        {/* <div className="flex flex-col items-center lg:items-start">

          <div className="relative">
            <div className="absolute -inset-3 bg-primary-100 rounded-3xl rotate-3"></div>

            <img
              src="/deepak image.jpeg"
              alt={portfolioData.personal.name}
              className="relative w-64 h-64 object-cover rounded-3xl shadow-xl"
            />
          </div>

          <div className="mt-6 text-center lg:text-left">
            <h3 className="text-2xl font-bold text-gray-900">
              {portfolioData.personal.name}
            </h3>

            <p className="text-primary-600 font-medium mt-1">
              Full Stack Developer
            </p>
          </div>

        
        </div> */}


        <div className="h-full min-h-[600px]">
  <div className="relative h-full w-full overflow-hidden rounded-3xl bg-primary-50 border border-gray-100 shadow-sm">

    <img
      src="/deepak image.jpeg"
      alt={portfolioData.personal.name}
      className="w-full h-full object-cover"
    />

    {/* Bottom overlay */}
    <div className="absolute bottom-0 left-0 right-0 bg-white/95 backdrop-blur-sm p-6">
      <h3 className="text-2xl font-bold text-gray-900">
        {portfolioData.personal.name}
      </h3>

      <p className="text-primary-600 font-medium mt-1">
        Full Stack Developer
      </p>
    </div>

  </div>
</div>


        {/* Right - About Content */}
        <div>

          <span className="inline-flex items-center px-4 py-2 rounded-full bg-primary-50 text-primary-600 text-sm font-semibold mb-5">
            Full Stack Developer
          </span>

          <h3 className="text-3xl font-bold text-gray-900 mb-5">
            Building scalable solutions for real-world problems.
          </h3>

          <p className="text-lg text-gray-600 leading-relaxed mb-5">
            {portfolioData.personal.summary}
          </p>

          <p className="text-lg text-gray-600 leading-relaxed">
            I specialize in{' '}
            {portfolioData.skills.frontend.slice(0, 3).join(', ')}
            {' '}on the frontend, and{' '}
            {portfolioData.skills.backend.slice(0, 3).join(', ')}
            {' '}on the backend.
          </p>


          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mt-8">

            <div className="bg-gray-50 rounded-2xl p-5 text-center border border-gray-100">
              <h4 className="text-2xl font-bold text-primary-600">
                1.5+
              </h4>
              <p className="text-sm text-gray-500 mt-1">
                Years Experience
              </p>
            </div>

            <div className="bg-gray-50 rounded-2xl p-5 text-center border border-gray-100">
              <h4 className="text-2xl font-bold text-primary-600">
                Full
              </h4>
              <p className="text-sm text-gray-500 mt-1">
                Stack Developer
              </p>
            </div>

            <div className="bg-gray-50 rounded-2xl p-5 text-center border border-gray-100">
              <h4 className="text-2xl font-bold text-primary-600">
                AWS
              </h4>
              <p className="text-sm text-gray-500 mt-1">
                Cloud Deployment
              </p>
            </div>

          </div>


          {/* Core Technologies */}
          <div className="mt-8">

            <h4 className="text-sm font-bold uppercase tracking-wider text-gray-900 mb-4">
              Core Technologies
            </h4>

            <div className="flex flex-wrap gap-2">

              {[
                'React.js',
                'Node.js',
                'Express.js',
                'JavaScript',
                'TypeScript',
                'MySQL',
                'MongoDB',
                'AWS'
              ].map((tech) => (
                <span
                  key={tech}
                  className="px-3 py-2 bg-white border border-gray-200 rounded-full text-sm font-medium text-gray-700 hover:border-primary-300 hover:text-primary-600 transition-colors"
                >
                  {tech}
                </span>
              ))}

            </div>

          </div>

        </div>

      </div>
    </SectionWrapper>
  );
};

export default AboutSection;