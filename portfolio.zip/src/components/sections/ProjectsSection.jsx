// import React from 'react';
// import { portfolioData } from '../../data/portfolioData';
// import SectionWrapper from '../layout/SectionWrapper';
// import { ExternalLink } from 'lucide-react';
// import { FaGithub } from 'react-icons/fa';

// const ProjectsSection = () => {
//   return (
//     <SectionWrapper id="projects" title="Featured Projects" className="bg-gray-50">
//       <div className="space-y-12">
//         {portfolioData.projects.map((project, index) => (
//           <div 
//             key={index} 
//             className="bg-white rounded-3xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-lg transition-all duration-300 flex flex-col lg:flex-row group"
//           >
//             {/* Visual placeholder for the project - since we don't have images in resume */}
//             <div className="lg:w-1/3 bg-primary-50 p-8 flex items-center justify-center border-b lg:border-b-0 lg:border-r border-gray-100">
//               <div className="text-center">
//                 <div className="w-16 h-16 bg-white rounded-2xl shadow-sm flex items-center justify-center mx-auto mb-4 text-primary-600 font-bold text-2xl border border-primary-100">
//                   {project.name.charAt(0)}
//                 </div>
//                 <h4 className="font-bold text-gray-900 text-lg">
//                   {project.name.split('—')[0].trim()}
//                 </h4>
//                 <p className="text-sm text-primary-600 font-medium mt-1">
//                   {project.name.split('—')[1]?.trim()}
//                 </p>
//               </div>
//             </div>
            
//             <div className="lg:w-2/3 p-8">
//               <p className="text-gray-600 mb-6 text-lg">
//                 {project.description}
//               </p>
              
//               <div className="mb-6">
//                 <h5 className="text-sm font-bold text-gray-900 uppercase tracking-wider mb-3">Key Features</h5>
//                 <ul className="list-disc list-outside ml-4 text-gray-600 space-y-2 text-sm">
//                   {project.details.map((detail, idx) => (
//                     <li key={idx} className="pl-1">{detail}</li>
//                   ))}
//                 </ul>
//               </div>
              
//               <div className="mt-auto">
//                 <h5 className="text-sm font-bold text-gray-900 uppercase tracking-wider mb-3">Tech Stack</h5>
//                 <div className="flex flex-wrap gap-2 mb-6">
//                   {project.techStack.map((tech, idx) => (
//                     <span 
//                       key={idx} 
//                       className="px-3 py-1 bg-gray-100 text-gray-700 text-xs font-semibold rounded-full border border-gray-200"
//                     >
//                       {tech}
//                     </span>
//                   ))}
//                 </div>
                
//                 <div className="flex gap-4">
//                   <button className="flex items-center text-sm font-semibold text-gray-500 hover:text-gray-900 transition-colors cursor-not-allowed opacity-50" title="Link not provided in resume">
//                     <ExternalLink size={16} className="mr-1.5" />
//                     Live Demo
//                   </button>
//                   <button className="flex items-center text-sm font-semibold text-gray-500 hover:text-gray-900 transition-colors cursor-not-allowed opacity-50" title="Link not provided in resume">
//                     <FaGithub size={16} className="mr-1.5" />
//                     Source Code
//                   </button>
//                 </div>
//               </div>
//             </div>
//           </div>
//         ))}
//       </div>
//     </SectionWrapper>
//   );
// };

// export default ProjectsSection;



import React from 'react';
import { portfolioData } from '../../data/portfolioData';
import SectionWrapper from '../layout/SectionWrapper';
import { ExternalLink } from 'lucide-react';
import { FaGithub } from 'react-icons/fa';

const ProjectsSection = () => {
  return (
    <SectionWrapper
      id="projects"
      title="Featured Projects"
      className="bg-gray-50"
    >
      <div className="space-y-12">
        {portfolioData.projects.map((project, index) => (
          // <div
          //   key={index}
          //   className="bg-white rounded-3xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-lg transition-all duration-300 flex flex-col lg:flex-row group"
          // >

          //   {/* Project Image */}
          //   <div className="lg:w-1/3 bg-primary-50 border-b lg:border-b-0 lg:border-r border-gray-100 overflow-hidden">
          //     <img
          //       src={project.image}
          //       alt={project.name}
          //       className="w-full h-full min-h-[300px] lg:min-h-[500px] object-cover"
          //     />
          //   </div>

          //   {/* Project Details */}
          //   <div className="lg:w-2/3 p-8">

          //     <p className="text-gray-600 mb-6 text-lg">
          //       {project.description}
          //     </p>

          //     <div className="mb-6">
          //       <h5 className="text-sm font-bold text-gray-900 uppercase tracking-wider mb-3">
          //         Key Features
          //       </h5>

          //       <ul className="list-disc list-outside ml-4 text-gray-600 space-y-2 text-sm">
          //         {project.details.map((detail, idx) => (
          //           <li key={idx} className="pl-1">
          //             {detail}
          //           </li>
          //         ))}
          //       </ul>
          //     </div>

          //     <div className="mt-auto">
          //       <h5 className="text-sm font-bold text-gray-900 uppercase tracking-wider mb-3">
          //         Tech Stack
          //       </h5>

          //       <div className="flex flex-wrap gap-2 mb-6">
          //         {project.techStack.map((tech, idx) => (
          //           <span
          //             key={idx}
          //             className="px-3 py-1 bg-gray-100 text-gray-700 text-xs font-semibold rounded-full border border-gray-200"
          //           >
          //             {tech}
          //           </span>
          //         ))}
          //       </div>

          //       <div className="flex gap-4">
          //         <button
          //           className="flex items-center text-sm font-semibold text-gray-500 hover:text-gray-900 transition-colors cursor-not-allowed opacity-50"
          //           title="Link not provided in resume"
          //         >
          //           <ExternalLink size={16} className="mr-1.5" />
          //           Live Demo
          //         </button>

          //         <button
          //           className="flex items-center text-sm font-semibold text-gray-500 hover:text-gray-900 transition-colors cursor-not-allowed opacity-50"
          //           title="Link not provided in resume"
          //         >
          //           <FaGithub size={16} className="mr-1.5" />
          //           Source Code
          //         </button>
          //       </div>
          //     </div>

          //   </div>
          // </div>

          <div
  key={index}
  className="bg-white rounded-3xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-lg transition-all duration-300 flex flex-col lg:flex-row group"
>
  {/* Project Image */}
  <div className="lg:w-1/3 bg-primary-50 border-b lg:border-b-0 lg:border-r border-gray-100 flex items-center justify-center p-6">
    <div className="w-full h-[320px] lg:h-[500px] flex items-center justify-center">
      <img
        src={project.image}
        alt={project.name}
        className="w-full h-full object-contain"
      />
    </div>
  </div>

  {/* Project Details */}
  <div className="lg:w-2/3 p-8 flex flex-col">

    {/* Project Name */}
    <div className="mb-5">
      <h3 className="text-2xl lg:text-3xl font-bold text-gray-900">
        {project.name.split('—')[0].trim()}
      </h3>

      <p className="text-primary-600 font-medium mt-1">
        {project.name.split('—')[1]?.trim()}
      </p>
    </div>

    {/* Description */}
    <p className="text-gray-600 mb-6 text-lg">
      {project.description}
    </p>

    {/* Key Features */}
    <div className="mb-6">
      <h5 className="text-sm font-bold text-gray-900 uppercase tracking-wider mb-3">
        Key Features
      </h5>

      <ul className="list-disc list-outside ml-4 text-gray-600 space-y-2 text-sm">
        {project.details.map((detail, idx) => (
          <li key={idx} className="pl-1">
            {detail}
          </li>
        ))}
      </ul>
    </div>

    {/* Tech Stack */}
    <div className="mt-auto">
      <h5 className="text-sm font-bold text-gray-900 uppercase tracking-wider mb-3">
        Tech Stack
      </h5>

      <div className="flex flex-wrap gap-2 mb-6">
        {project.techStack.map((tech, idx) => (
          <span
            key={idx}
            className="px-3 py-1 bg-gray-100 text-gray-700 text-xs font-semibold rounded-full border border-gray-200"
          >
            {tech}
          </span>
        ))}
      </div>

      {/* Links */}
      <div className="flex gap-4">
        <button
          className="flex items-center text-sm font-semibold text-gray-500 hover:text-gray-900 transition-colors cursor-not-allowed opacity-50"
          title="Link not provided in resume"
        >
          <ExternalLink size={16} className="mr-1.5" />
          Live Demo
        </button>

        <button
          className="flex items-center text-sm font-semibold text-gray-500 hover:text-gray-900 transition-colors cursor-not-allowed opacity-50"
          title="Link not provided in resume"
        >
          <FaGithub size={16} className="mr-1.5" />
          Source Code
        </button>
      </div>
    </div>
  </div>
</div>
        ))}
      </div>
    </SectionWrapper>
  );
};

export default ProjectsSection;