import React from 'react';
import { portfolioData } from '../../data/portfolioData';
import SectionWrapper from '../layout/SectionWrapper';
import { Briefcase, Calendar, MapPin } from 'lucide-react';

const ExperienceSection = () => {
  return (
    <SectionWrapper id="experience" title="Professional Experience" className="bg-white">
      <div className="relative border-l border-gray-200 ml-3 md:ml-6 space-y-12">
        {portfolioData.experience.map((exp, index) => (
          <div key={index} className="relative pl-8 md:pl-10">
            {/* Timeline Dot */}
            <div className="absolute w-4 h-4 bg-primary-600 rounded-full -left-[9px] top-1.5 ring-4 ring-white"></div>
            
            <div className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow group">
              <div className="flex flex-col md:flex-row md:items-start md:justify-between mb-4 gap-4">
                <div>
                  <h3 className="text-xl font-bold text-gray-900 group-hover:text-primary-600 transition-colors">
                    {exp.role}
                  </h3>
                  <div className="flex items-center text-lg font-medium text-gray-700 mt-1">
                    <Briefcase size={18} className="mr-2 text-gray-400" />
                    {exp.company}
                  </div>
                </div>
                <div className="flex flex-col items-start md:items-end text-sm text-gray-500 space-y-1">
                  <div className="flex items-center bg-gray-50 px-3 py-1 rounded-full border border-gray-200">
                    <Calendar size={14} className="mr-1.5 text-gray-400" />
                    {exp.duration}
                  </div>
                  <div className="flex items-center text-gray-500 px-3 py-1">
                    <MapPin size={14} className="mr-1.5 text-gray-400" />
                    {exp.location}
                  </div>
                </div>
              </div>
              
              <ul className="list-disc list-outside ml-5 text-gray-600 space-y-2 mt-4 text-sm md:text-base">
                {exp.responsibilities.map((task, idx) => (
                  <li key={idx} className="pl-1">
                    {task}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>
    </SectionWrapper>
  );
};

export default ExperienceSection;
