import React from 'react';
import { portfolioData } from '../../data/portfolioData';
import SectionWrapper from '../layout/SectionWrapper';

const SkillsSection = () => {
  const categories = [
    { title: 'Languages', items: portfolioData.skills.languages },
    { title: 'Frontend', items: portfolioData.skills.frontend },
    { title: 'Backend', items: portfolioData.skills.backend },
    { title: 'Database', items: portfolioData.skills.database },
    { title: 'Cloud & AI', items: portfolioData.skills.cloudAndAI },
    { title: 'Tools & Platforms', items: portfolioData.skills.toolsAndPlatforms },
    // { title: 'Concepts', items: portfolioData.skills.concepts },
  ];

  return (
    <SectionWrapper id="skills" title="Technical Skills" className="bg-gray-50">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {categories.map((category, index) => (
          <div key={index} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 pb-2 border-b border-gray-100">
              {category.title}
            </h3>
            <div className="flex flex-wrap gap-2">
              {category.items.map((item, idx) => (
                <span 
                  key={idx} 
                  className="px-3 py-1 bg-primary-50 text-primary-700 text-sm font-medium rounded-md border border-primary-100"
                >
                  {item}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </SectionWrapper>
  );
};

export default SkillsSection;
